__MODULE__ = "colong"
__HELP__ = """
<blockquote><b>Bantuan Untuk Colong

perintah : <code>{0}colong</code>
Untuk Mengambil Media/vidio Yang 1x Lihat</b></blockquote>
"""
